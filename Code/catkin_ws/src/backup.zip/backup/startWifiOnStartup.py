#ooga booga
import os
from time import sleep

sleep(30)
os.system("sh disableAP.sh")
sleep(5)
os.system("sh enableAP.sh")

os.system("echo ooga booga")
