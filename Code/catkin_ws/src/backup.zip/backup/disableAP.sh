sudo systemctl stop hostapd;
sudo systemctl stop dnsmasq;
sudo systemctl disable hostapd;
sudo systemctl disable dnsmasq;
sudo cp /etc/dhcpcd_disable.conf /etc/dhcpcd.conf
echo "reboot your system"