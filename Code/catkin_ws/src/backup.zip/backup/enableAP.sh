sudo cp /etc/dhcpcd_enable.conf /etc/dhcpcd.conf
sudo systemctl enable hostapd;
sudo systemctl enable dnsmasq;
sudo systemctl start hostapd;
sudo systemctl start dnsmasq;
echo "reboot your system"