export ROS_MASTER_URI=http://BaseBot.local:11311
export ROS_IP=192.168.0.10
echo "set ROS_MASTER_URI and ROS_IP for BaseBot"
cd ../Beachbots/Code/catkin_ws
$SHELL